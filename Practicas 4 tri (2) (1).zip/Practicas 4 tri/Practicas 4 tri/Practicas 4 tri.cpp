// buscaminas.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Window.h"
#include "Image.h"
#include "Player.h"

int main(int argc, char* args[])
{
    int DirX;
    int DirY;
    Window* window = Window::GetPtr();
    window->Init();
    Player p;
    p.Init();
    while (true)
    {
        window->Clear();
        window->Input(DirX, DirY);
        if (DirY > 0)
        {
            p.y -= 0.1;
        }
        else if (DirY < 0)
        {
            p.y += 0.1;
        }
        p.Draw();
        window->Render();
    }

    std::cout << "Hello World!\n";
    return 0;
}

